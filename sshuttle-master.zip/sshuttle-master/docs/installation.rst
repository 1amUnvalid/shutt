Installation
============

- From PyPI::

      pip install sshuttle

- Debian package manager::

      sudo apt install sshuttle

- Clone::

      git clone https://github.com/sshuttle/sshuttle.git
      cd sshuttle
      ./setup.py install


Optionally after installation
-----------------------------

- Install sudoers configuration. For details, see the "Sudoers File" section in :doc:`usage`

