Support
=======

Mailing list:

* Subscribe by sending a message to <sshuttle+subscribe@googlegroups.com>
* List archives are at: http://groups.google.com/group/sshuttle

Issue tracker and pull requests at github:

* https://github.com/sshuttle/sshuttle
